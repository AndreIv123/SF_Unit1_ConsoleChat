var searchData=
[
  ['id_0',['id',['../classUniq.html#a10124f699ba857b0ca10bb24ce3bb8ed',1,'Uniq']]],
  ['id_1',['ID',['../structUniq_1_1ID.html',1,'Uniq']]],
  ['index_2',['index',['../classChat.html#ae53aec618a443f2a7351d63d26dc57bc',1,'Chat']]],
  ['input_3',['input',['../classMenu.html#a551f76c40292841b65c0833f251cf61e',1,'Menu']]],
  ['isoptionidxinmenu_4',['isOptionIdxInMenu',['../classMenu.html#a4123ecbac47cae24cc4e6aeebe7a5c4e',1,'Menu']]]
];
