var searchData=
[
  ['uniq_0',['Uniq',['../classUniq.html',1,'Uniq'],['../classUniq.html#ab484d4a88cf1ad7091a12f5bf8916a77',1,'Uniq::Uniq()']]],
  ['uniqid_2ecpp_1',['UniqID.cpp',['../UniqID_8cpp.html',1,'']]],
  ['uniqid_2eh_2',['UniqID.h',['../UniqID_8h.html',1,'']]],
  ['user_3',['User',['../classUser.html',1,'']]],
  ['user_4',['user',['../classChat.html#afb4bb4f5204347c3ae265965003b4f03',1,'Chat::user(const std::string &amp;login) -&gt; std::shared_ptr&lt; User &gt;'],['../classChat.html#a4210cd94fd6086a34c3619c5d377b1e7',1,'Chat::user(const Uniq::ID &amp;id) -&gt; std::shared_ptr&lt; User &gt;']]],
  ['user_5',['User',['../classUser.html#a97117d86505482f0ab54e485c5a74620',1,'User']]],
  ['user_2ecpp_6',['User.cpp',['../User_8cpp.html',1,'']]],
  ['user_2eh_7',['User.h',['../User_8h.html',1,'']]],
  ['usersexists_8',['usersExists',['../classChat.html#aa0deddcd0ceeb309e5e474b16ae07f51',1,'Chat']]],
  ['usersids_9',['usersIDs',['../classChat.html#abad690c14bdd7b3d119147df6c2851fa',1,'Chat']]],
  ['usersnamebyid_10',['usersNameByID',['../classChat.html#a710bc96f6aeee018be56845536fa280f',1,'Chat']]],
  ['usersnumber_11',['usersNumber',['../classChat.html#ab66ab0586aacfca5d6d0de2ab5550444',1,'Chat']]],
  ['usersregist_12',['usersRegist',['../classChat.html#a0c34d4dd07c48b234653b50801df19b3',1,'Chat']]],
  ['usersrename_13',['usersRename',['../classChat.html#a90a032c265e3e52509eed4129031dc68',1,'Chat']]]
];
