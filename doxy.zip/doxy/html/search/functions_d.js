var searchData=
[
  ['verify_0',['verify',['../classAccount.html#ad96307ff54befd8be6b10ea26be91b90',1,'Account']]]
];
