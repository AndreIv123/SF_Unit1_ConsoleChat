var searchData=
[
  ['verify_0',['verify',['../classUser.html#a3ffb6b8eea347ebcf2723de5e608b774',1,'User']]]
];
