var searchData=
[
  ['getactiveid_0',['getActiveID',['../classChat.html#acbafc41cadebfb48ef698bbbc061be9e',1,'Chat']]],
  ['getactivelogin_1',['getActiveLogin',['../classChat.html#ad6aa066fffe5d48fee218334dee99675',1,'Chat']]],
  ['getlogin_2',['getLogin',['../classUser.html#a1e653278570a731b14a7f150cd1327bb',1,'User']]],
  ['getname_3',['getName',['../classUser.html#a24c6e14f6c0c43a0ed4d0ffc27860a4b',1,'User']]],
  ['getsenderid_4',['getSenderID',['../classMessage.html#a1115275312585eee3612fc504585ea78',1,'Message']]],
  ['gettext_5',['getText',['../classMessage.html#a7fb171e986ff8070f468afa53eca3db8',1,'Message']]],
  ['getunread_6',['getUnread',['../classUser.html#ae05578eb524e2e5c9d7649ed08972b21',1,'User']]]
];
