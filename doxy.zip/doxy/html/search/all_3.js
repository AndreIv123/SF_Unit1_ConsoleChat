var searchData=
[
  ['entry_0',['Entry',['../structMenu_1_1Entry.html#ab88ad6c623706fc1db0eec5bd53a0371',1,'Menu::Entry::Entry(const std::string &amp;lbl, respond act)'],['../structMenu_1_1Entry.html#a23255172f11fb1ab5be174cd71cadb5a',1,'Menu::Entry::Entry()=default'],['../structMenu_1_1Entry.html',1,'Menu::Entry']]]
];
