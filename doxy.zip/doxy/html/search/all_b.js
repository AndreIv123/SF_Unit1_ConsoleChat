var searchData=
[
  ['setflagexpectuserinput_0',['setFlagExpectUserInput',['../classMenu.html#ac317a72e3f5e8679f07a44b24ce2c615',1,'Menu']]],
  ['setflagpromtuntilvalid_1',['setFlagPromtUntilValid',['../classMenu.html#a9d574c660f80e44cedd5d76bb25de0b9',1,'Menu']]],
  ['setflagrepeatmenu_2',['setFlagRepeatMenu',['../classMenu.html#a49f49076752518a5e0662d14c0fe5029',1,'Menu']]],
  ['setflagzerooptionlast_3',['setFlagZeroOptionLast',['../classMenu.html#a77fbb82d8c60f66fffd25bb4c810fbf6',1,'Menu']]],
  ['setfooter_4',['setFooter',['../classMenu.html#aa7c5021d94e8dcac934bb1f350324db6',1,'Menu']]],
  ['setheader_5',['setHeader',['../classMenu.html#a93abc04a62fc5b1fd7db617806e416ca',1,'Menu']]],
  ['setname_6',['setName',['../classUser.html#abe087f191699f9d61bdc94d041e4fada',1,'User']]],
  ['setpromt_7',['setPromt',['../classMenu.html#ac2f9a43ad126995b9ca3b2c93d1b665f',1,'Menu']]],
  ['shouldrepeatmenu_8',['shouldRepeatMenu',['../classMenu.html#a5155e83bd5904eaf9284bb4d10c0f756',1,'Menu']]]
];
