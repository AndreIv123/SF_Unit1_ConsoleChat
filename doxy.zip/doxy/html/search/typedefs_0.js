var searchData=
[
  ['respond_0',['respond',['../classMenu.html#a5dd130d11d1ded287519b05716120e34',1,'Menu']]]
];
